# Compact Security-Evidence Experiments

This experiment family contains retained artifacts used to evaluate admission,
tamper detection, commitment recomputation, scoped Groth16/public-input
verification, layered off-chain overhead, and evidence export.

These security-evidence runs are distinct from the manuscript's main predictive
utility result bundles.
