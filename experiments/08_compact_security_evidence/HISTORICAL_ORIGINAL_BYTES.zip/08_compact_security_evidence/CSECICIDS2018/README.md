# Compact Security-Evidence Run — CSE-CIC-IDS2018

This directory contains the retained compact **security-evidence / verification**
run that was previously misclassified under `01_primary_compact/fl_bc_ids_dp`.

The reclassification is intentional: the original `rsu_outputs_dp` tree contains
dedicated ablation reports, tamper probes, commitment-recomputation outputs,
public-input verification outputs, generated Groth16 circuits, proof artifacts,
round manifests, and on-chain export material. It is therefore treated here as
the compact security-evidence workflow rather than as the authoritative
historical predictive-utility result bundle for the manuscript's main benchmark
table.

`run_outputs/` preserves the earlier curated output subset.
`verification_evidence/` contains the authoritative verification artifacts copied
from the original project.

No claim is made that this directory is the missing historical main utility run.
